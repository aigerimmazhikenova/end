public class User {
    private String firstName;
    private String secondName;
    private int id;
    private int age;
    private String gender;
    private String password;
    private String dateOfBirth;
    private static int k=0;

    public User(String firstName, String secondName, int id, int age, String gender, String password, String dateOfBirth) {
        this.firstName = firstName;
        this.secondName = secondName;
        this.id=k++;
        this.age = age;
        this.gender = gender;
        this.password = password;
        this.dateOfBirth = dateOfBirth;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        id++;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public void displayInfo() {
        System.out.println(firstName+" "+secondName+" "+id+" "+age+" "+gender+" "+password+" "+dateOfBirth);
    }
}
