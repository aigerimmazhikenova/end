import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class Validator {
    User user;
    public boolean checkAge(){
        if (user.getAge()>18)
        {
            System.out.println("Adult");
            return true;
        }
        else return false;
    }
    public boolean checkPassword(){
        String passwd="(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!^]).{8,}";
        if(!user.getPassword().matches(passwd)){
            return false;
        }
        return true;
    }

    public boolean checkDate(){
        String dateformat="(?:(?:19|2[01])\\d\\d\\/(?:1[02]|0[13578])\\/(?:[0-2]\\d|3[01]))";
        if (user.getDateOfBirth().equals(dateformat){
            return true;
        }
        return false;
    }

}
