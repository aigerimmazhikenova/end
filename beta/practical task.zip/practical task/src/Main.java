import java.util.Scanner;

public class Main {
    public static void main(String args[] ) {
        Scanner in=new Scanner(System.in);
        User user=new User();
        user.setFirstName(in.nextLine());
        user.setSecondName(in.nextLine());
        user.setAge(in.nextInt());
        user.setGender(in.nextLine());
        user.setPassword(in.nextLine());
        user.setDateOfBirth(in.nextLine());
        user.displayInfo();
        Validator validator= new Validator(user);

        validator.checkAge();
        validator.checkPassword();
        validator.checkDate();

    }
}
